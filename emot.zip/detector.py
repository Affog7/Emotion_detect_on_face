import cv2
import numpy as np
import streamlit as st
from tensorflow.keras.models import load_model
from PIL import Image
import tempfile

class EmotionDetector:
    def __init__(self, model_path='emotion_model.h5'):
        # Chargement du modèle
        self.model = load_model(model_path)
        
        # Chargement du détecteur de visages
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        
        # Dictionnaire des émotions
        self.emotions = {
            0: 'Angry',
            1: 'Disgust',
            2: 'Fear',
            3: 'Happy',
            4: 'Sad',
            5: 'Surprise',
            6: 'Neutral'
        }
    
    def preprocess_face(self, face_img):
        """Prétraite l'image du visage pour l'inférence"""
        face_img = cv2.resize(face_img, (48, 48))
        if len(face_img.shape) == 3:
            face_img = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
        face_img = face_img.astype('float32') / 255.0
        face_img = np.expand_dims(face_img, axis=-1)
        face_img = np.expand_dims(face_img, axis=0)
        return face_img
    
    def detect_emotion(self, image):
        """Détecte les émotions dans une image"""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.2,  # Augmenté pour réduire les faux positifs
            minNeighbors=6,  # Plus strict sur les détections
            minSize=(50, 50)  # Augmenter la taille minimale du visage détecté
        )
        
        results = []
        for (x, y, w, h) in faces:
            face_roi = gray[y:y+h, x:x+w]
            processed_face = self.preprocess_face(face_roi)
            predictions = self.model.predict(processed_face)
            emotion_idx = np.argmax(predictions[0])
            emotion = self.emotions[emotion_idx]
            confidence = float(predictions[0][emotion_idx])
            
            results.append({
                'bbox': (x, y, w, h),
                'emotion': emotion,
                'confidence': confidence,
                'probabilities': {self.emotions[i]: float(prob) for i, prob in enumerate(predictions[0])}
            })
        
        return results
    
    def draw_results(self, image, results):
        """Dessine les résultats sur l'image"""
        output = image.copy()
        for result in results:
            x, y, w, h = result['bbox']
            emotion = result['emotion']
            confidence = result['confidence']
            cv2.rectangle(output, (x, y), (x+w, y+h), (0, 255, 0), 2)
            text = f"{emotion}: {confidence:.2f}"
            cv2.putText(output, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        return output

# Interface Streamlit
st.title("Détection des Émotions sur Image et Vidéo")

uploaded_file = st.file_uploader("Choisissez une image ou une vidéo", type=["jpg", "png", "jpeg", "mp4", "avi", "mov"])

detector = EmotionDetector('emotion_model.h5')

if uploaded_file is not None:
    file_extension = uploaded_file.name.split(".")[-1].lower()
    
    if file_extension in ["jpg", "png", "jpeg"]:
        image = Image.open(uploaded_file)
        image = np.array(image)
        
        results = detector.detect_emotion(image)
        output_image = detector.draw_results(image, results)
        
        col1, col2 = st.columns(2)
        with col1:
            st.image(output_image, caption="Résultat de la détection", use_container_width=True)
        with col2:
            for result in results:
                st.write(f"**Emotion détectée:** {result['emotion']}")
                st.write(f"**Confiance:** {result['confidence']:.2f}")
    
    elif file_extension in ["mp4", "avi", "mov"]:
        tfile = tempfile.NamedTemporaryFile(delete=False)
        tfile.write(uploaded_file.read())
        
        cap = cv2.VideoCapture(tfile.name)
        
        stframe = st.empty()
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            results = detector.detect_emotion(frame)
            output_frame = detector.draw_results(frame, results)
            
            stframe.image(output_frame, channels="BGR", use_container_width=True)
        
        cap.release()
