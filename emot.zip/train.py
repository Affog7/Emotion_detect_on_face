import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns

# Configuration
IMG_HEIGHT = 48
IMG_WIDTH = 48
BATCH_SIZE = 64
EPOCHS = 50
NUM_CLASSES = 7  # (angry, disgust, fear, happy, sad, surprise, neutral)

def load_fer2013():
    """Charge et prétraite le dataset FER2013"""
    data = pd.read_csv('fer2013.csv')
    
    # Conversion des pixels string en tableaux numpy
    pixels = data['pixels'].apply(lambda x: np.array(x.split(' ')).astype('float32'))
    
    # Normalisation des pixels
    X = np.stack(pixels.values)
    X = X.reshape(-1, IMG_HEIGHT, IMG_WIDTH, 1)
    X = X / 255.0
    
    # Conversion des labels en one-hot encoding
    y = pd.get_dummies(data['emotion']).values
    
    return X, y

def create_model():
    """Crée le modèle CNN pour la détection d'émotions"""
    model = Sequential([
        Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(48, 48, 1)),
        Conv2D(64, kernel_size=(3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        Conv2D(128, kernel_size=(3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Conv2D(128, kernel_size=(3, 3), activation='relu'),
        MaxPooling2D(pool_size=(2, 2)),
        Dropout(0.25),
        
        Flatten(),
        Dense(1024, activation='relu'),
        Dropout(0.5),
        Dense(7, activation='softmax')
    ])
    
    return model

def plot_training_history(history):
    """Affiche les courbes d'apprentissage"""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    
    # Courbe de précision
    ax1.plot(history.history['accuracy'], label='train')
    ax1.plot(history.history['val_accuracy'], label='validation')
    ax1.set_title('Précision du modèle')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Précision')
    ax1.legend()
    
    # Courbe de perte
    ax2.plot(history.history['loss'], label='train')
    ax2.plot(history.history['val_loss'], label='validation')
    ax2.set_title('Perte du modèle')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Perte')
    ax2.legend()
    
    plt.tight_layout()
    plt.show()

def train_model():
    """Entraîne le modèle sur FER2013"""
    # Chargement des données
    print("Chargement du dataset FER2013...")
    X, y = load_fer2013()
    
    # Split des données
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)
    
    # Data augmentation
    datagen = ImageDataGenerator(
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest'
    )
    
    # Création du modèle
    print("Création du modèle...")
    model = create_model()
    
    # Compilation du modèle
    model.compile(
        optimizer=Adam(learning_rate=0.0001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    # Callbacks
    early_stopping = tf.keras.callbacks.EarlyStopping(
        monitor='val_loss',
        patience=10,
        restore_best_weights=True
    )
    
    reduce_lr = tf.keras.callbacks.ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.2,
        patience=5,
        min_lr=1e-7
    )
    
    # Entraînement du modèle
    print("Début de l'entraînement...")
    history = model.fit(
        datagen.flow(X_train, y_train, batch_size=BATCH_SIZE),
        epochs=EPOCHS,
        validation_data=(X_val, y_val),
        callbacks=[early_stopping, reduce_lr]
    )
    
    # Évaluation du modèle
    print("Évaluation du modèle...")
    test_loss, test_accuracy = model.evaluate(X_test, y_test)
    print(f"Test accuracy: {test_accuracy:.4f}")
    print(f"Test loss: {test_loss:.4f}")
    
    # Affichage des courbes d'apprentissage
    plot_training_history(history)
    
    # Sauvegarde du modèle
    model.save('emotion_model.h5')
    print("Modèle sauvegardé sous 'emotion_model.h5'")
    
    return model, history

# Fonction pour l'évaluation détaillée
def evaluate_model(model, X_test, y_test):
    """Évalue le modèle et affiche la matrice de confusion"""
    # Prédictions sur le jeu de test
    y_pred = model.predict(X_test)
    y_pred_classes = np.argmax(y_pred, axis=1)
    y_true_classes = np.argmax(y_test, axis=1)
    
    # Matrice de confusion
    confusion_mtx = tf.math.confusion_matrix(y_true_classes, y_pred_classes)
    
    # Affichage de la matrice de confusion
    plt.figure(figsize=(10, 8))
    sns.heatmap(confusion_mtx, 
                annot=True, 
                fmt='d',
                cmap='Blues',
                xticklabels=['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral'],
                yticklabels=['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral'])
    plt.title('Matrice de Confusion')
    plt.xlabel('Prédictions')
    plt.ylabel('Vraies Valeurs')
    plt.show()

if __name__ == "__main__":
    # Entraînement du modèle
    model, history = train_model()
    
    # Chargement des données de test pour l'évaluation
    X, y = load_fer2013()
    _, X_test, _, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Évaluation détaillée
    evaluate_model(model, X_test, y_test)